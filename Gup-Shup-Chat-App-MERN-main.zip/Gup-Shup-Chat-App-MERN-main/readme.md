***** Homewords

- Infinite scroll pagination for other users // infinite-react-scroll
- Infinite scroll pagination for messages
- clear data on page unmount and logout (cleanup)
- implement loaders (screenloaders and buttonloaders)
- Profile page (Edit Profile);
